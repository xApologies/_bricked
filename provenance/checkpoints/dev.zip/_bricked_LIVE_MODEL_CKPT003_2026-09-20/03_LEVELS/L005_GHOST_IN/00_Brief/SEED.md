# L005 — GHOST IN

Status: CONCEPT SEED / CKPT 0 NOT PASSED

Cybersecurity core: Lateral movement / shared locality
Genesis focus: Ghosting

See `08_LIVE_MODEL/Level_Arc/FIRST_ARC.md`. Explicit brief review is required before this level advances.
