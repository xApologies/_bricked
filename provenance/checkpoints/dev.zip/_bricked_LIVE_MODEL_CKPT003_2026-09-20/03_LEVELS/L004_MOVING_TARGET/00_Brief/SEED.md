# L004 — MOVING TARGET

Status: CONCEPT SEED / CKPT 0 NOT PASSED

Cybersecurity core: Dynamic credentials / key lifecycle
Genesis focus: DECS

See `08_LIVE_MODEL/Level_Arc/FIRST_ARC.md`. Explicit brief review is required before this level advances.
