# DECISION 0002 — Content-First Production
Accepted working rule:
Cybersecurity problem and level experience are designed first. Genesis Field / Chirality Fabric / propagation / PSSP / DECS / CDN mathematics are mapped to the level after objective, solution and brick paths are understood.

This prevents engine theory from dictating unnecessary puzzle content.
