# DECISION 0004 — Persistent DECS Keys
Persistent DECS Keys are rare reusable meta-progression objects. Most levels produce Flags only.
Keys may be combined in subsets as Bandwidth anchors/vertices to realize bounded Resolution fields and evolving cryptographic/geometric states.
Keys are not normally consumed.
