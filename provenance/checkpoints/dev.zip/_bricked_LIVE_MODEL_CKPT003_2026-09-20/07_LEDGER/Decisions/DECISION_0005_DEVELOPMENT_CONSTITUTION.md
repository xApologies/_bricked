# DECISION 0005 — Development Constitution Locked
All `_bricked` interactive domains use the same 00–14 development constitution and normalized 11D sandbox. LEVEL_XX is the canonical seed. Content may change; the pipeline remains stable unless explicitly revised with provenance.
