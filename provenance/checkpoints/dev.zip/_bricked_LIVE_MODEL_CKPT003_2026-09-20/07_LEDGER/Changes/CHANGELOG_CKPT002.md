# CKPT002 Change Ledger
- Shifted project emphasis from substrate invention to level/content production.
- Established no-fixed-level-count policy.
- Added six-act mastery structure.
- Added Genesis Literacy coverage matrix.
- Added sparse persistent DECS Key system.
- Defined Flags as frequent and Keys as rare/reusable.
- Added first ten post-intro level concepts.
- Added first-arc rule: approximately one major new concept per level.
- Preserved unresolved architecture as OPEN rather than inventing details.
