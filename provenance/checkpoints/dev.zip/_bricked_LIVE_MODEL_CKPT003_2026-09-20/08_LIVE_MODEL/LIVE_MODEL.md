# _bricked — LIVE MODEL
Checkpoint: CKPT002 | 2026-09-20 | CUMULATIVE WORKING MODEL

## Identity
`_bricked` is a visually explorable cybersecurity puzzle game: a visual debugger for an alien computer. Conventional cybersecurity reasoning remains underneath an alien Genesis implementation.

## Production order
LEVEL FANTASY → CYBERSECURITY PUZZLE → PLAYER SOLUTION → FAILURE/BRICK PATHS → GENESIS MAPPING → VISUAL MAPPING → Development Landscape gates.

Architecture is sufficient for content production; do not invent engine detail unless a level requires it.

## Visual ontology
COMPUTER STATE = WORLD STATE.
In Genesis, computation is visible as organized energy:
state→form; execution→evolution; communication→propagation; relationship→geometry; failure→loss of organization.

## Working stack
5D — dynamically recursive closed computational domain; working intuition B^5 / S^4 closure.
6D — hypercubic organizational read/write interface ("fence").
7D+8D — combined interactive/hackable Shell; exact topology OPEN.
9D+10D+11D — Genesis Horizon / containing reference/VM structure; individual semantics OPEN.
Python — sandbox + bidirectional transduction VM.
Platform — native adapter.
Renderer — GPU/device realization.

## Genesis Field / Chirality Fabric
Genesis Field is the native domain. Chirality Fabric organizes state, memory and relationships. Geometrics and 2×2×2 Chirality Bytes are native structured objects.

Resolution fields: R,O,Y,G,B,V. White is a derived full-superposed condition. Exact White coherence remains OPEN. Neon/Möbius underside remains RESERVED.
Objects anchor/own Bandwidth. Resolution describes locally available/readable organization.

## Waves / propagation
Wave-like fields are the visual/computational grammar. Superposition is a wave primitive. Chirality propagation inherits the Chirality Engine geometry. Quantum-inspired systems may be instantiated without making the entire game quantum mechanics.

## PSSP
Phase State Shadow Projection makes remote/higher-order structure locally readable. PSSP is distinct from source object, energy occupancy and manifested state. It can provide terminals, interfaces, debugging views and landscapes.

## Ghosting — RESERVED / WORKING
Do not overformalize.
Ghosting concerns interaction made possible when otherwise distinct Resolution domains become sufficiently unified/coupled. It may apply to distinct current objects or historical/provenance realizations. Exact mathematics and relationship to entanglement remain OPEN.

## Chirality Cycles / provenance
Genesis tracks evolution through Chirality Cycles. Horizon provides top-level ordering/reference while contained domains/objects may have independent local continuities/rates. Global ordering != local clock reading.

## Rainbow Road
Persistent/history-bearing transport organization and candidate native bus between Horizon and Python. Working concept: six color stacks R/O/Y/G/B/V; each may carry multiple logical propagation threads. Genesis logical concurrency need not equal hardware threading.

## Security
Guardian = integrity/admissibility observer/enforcer.
CDN = defensive/admissibility architecture.
DECS = dynamically evolving cryptographic/authority states.
Corridor = persistent admissible relationship.
Portal = transaction across Corridor.
Flag = local objective/proof artifact.
BRICKED = required objective becomes unreachable/unrecoverable in current run.

## Progression
Flags are common. Persistent DECS Keys are rare, reusable, history-bearing meta-progression objects. Keys may act as Bandwidth anchors/vertices and combine in subsets to realize target Resolution/graph/manifold conditions. Keys are not normally consumed.

## Game size
No fixed level count. Completion is Genesis fluency:
INTRODUCED → PRACTICED → COMBINED → MASTERED.
Acts: Discovery → Access → State → Ghost → Defense → Mastery.
Final act introduces no fundamental new mechanics.

## Content
Level 0: FIRST LIGHT intro/vertical-slice template.
Levels 1–10: first production arc, mapped in `Level_Arc/FIRST_ARC.md`.
