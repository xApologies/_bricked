# Visual Debugger for an Alien Computer
The player is still doing cybersecurity; the computer is alien.

Software has form. Computation appears as organized energy.
traffic→propagation; routing→Corridors/Rainbow Roads; process→evolving Geometric; memory→Fabric; trust→coupling; authorization→admissibility; credential→evolving authority object; failure→loss of organization.

Resolution is not camera zoom. Higher Resolution exposes deeper structure:
landscape → domain → structure → Geometric → Fabric → Chirality Byte.

The 7D/8D Shell is both enclosing layer and interactive command shell. Typed commands and gestures act on the same objects.
PSSP may materialize remote addresses/domains as locally readable alien terminals/landscapes.
Rendering fidelity may scale, but computational meaning must remain legible.
