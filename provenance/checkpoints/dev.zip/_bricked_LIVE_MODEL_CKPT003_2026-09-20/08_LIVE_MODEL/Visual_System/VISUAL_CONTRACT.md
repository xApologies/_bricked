# Genesis Visual Contract

`_bricked` is a visual debugger for an alien computer.

1. Important visuals correspond to machine state.
2. Increased Resolution reveals deeper computational structure; it is not merely camera zoom.
3. The same object may read as scenery to a beginner, an interface to an explorer, and an exploit surface to an expert.
4. Computation should feel alive through dynamic organized energy without requiring claims of biological life or consciousness.
5. PSSP can materialize locally readable terminals/interfaces/landscapes from remote or higher-order structures.
6. The terminal and gestures operate on the same authoritative objects.
7. Visual spectacle must preserve informational legibility across quality/performance settings.
