# Chirality Cycles — Working Model

A Chirality Cycle is a discrete state-evolution/provenance unit in Genesis.

Top-level Horizon reference:
H0 -> H1 -> H2 -> ...

Contained domains and objects may have independent local continuities:
A0 -> A1 -> A2 -> ...
B0 -> B1 -> B2 -> ...

At one Horizon reference state, different objects may occupy different local cycle indices and may evolve at different rates.

Provenance records both:
- machine/global ordering context;
- local object/domain evolution.

Potential gameplay:
- trace forward/backward through provenance;
- compare cycle states;
- resolve historical PSSP projections;
- synchronize independently evolving systems;
- investigate compromise/forensics;
- eventually Ghost compatible historical Resolution domains.

Open: exact cycle boundary rules; exact Horizon mathematics; whether authoritative history can ever be rewritten.
