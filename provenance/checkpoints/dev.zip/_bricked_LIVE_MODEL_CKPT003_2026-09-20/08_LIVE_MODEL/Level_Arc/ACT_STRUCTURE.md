# Complete Game Act Structure
Level count is emergent.

I Discovery — read the machine: Resolution, PSSP, addressing, probing, basic Corridors.
II Access — move through it: Rainbow Road, routing, trust, authentication, authorization.
III State — manipulate it: Bandwidth, waves, superposition, DECS, coupling.
IV Ghost — exploit relationships/locality/history: Ghosting, shared Resolution, provenance.
V Defense — fight its security: Guardian, CDN, detection, deception, recovery, deliberate bricking.
VI Mastery — think in Genesis: unfamiliar machines, combined systems, no new tutorial mechanics.

Stopping rule: required systems are introduced, practiced, combined and mastered; final integrated examination demonstrates fluency.
