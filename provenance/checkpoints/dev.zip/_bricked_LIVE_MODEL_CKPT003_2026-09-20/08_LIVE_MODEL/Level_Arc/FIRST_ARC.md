# FIRST PRODUCTION ARC — INTRO + LEVELS 1–10

0 FIRST LIGHT — intro/vertical slice. Observe before modification; address != access; intrusion != exfiltration; first BRICKED lesson.

1 NO SUCH HOST — discovery/enumeration; Resolution + PSSP. Find a computer that appears absent at current Resolution.

2 RAINBOW ROUTE — routing/topology; Corridors + Rainbow Road. Build a route through the alien network.

3 TRUST ME — trust boundaries/authentication vs authorization; Chirality coupling. Exploit what one machine trusts about another.

4 MOVING TARGET — dynamic credentials/key lifecycle; DECS. Authority evolves rather than remaining a copied password.

5 GHOST IN — lateral movement/shared locality; Ghosting. Exploit sufficiently unified Resolution domains rather than the front door.

6 THE MACHINE REMEMBERS — digital forensics; Chirality Cycles + provenance + historical PSSP. Walk backward through machine history.

7 GUARDIAN — detection/monitoring/evasion; Guardian + CDN. Operate maliciously while managing structural admissibility.

8 FALSE SHADOW — incomplete observation/representation risk; PSSP + Resolution. Projection != source.

9 SIX ROADS — concurrency/resource contention/synchronization; six Rainbow stacks + Bandwidth + White condition.

10 THE VAULT — integrated intrusion/exfiltration; combined learned stack. First complete alien-computer heist; no major new mechanic; escape topology altered by the player's own intrusion.

Arc constraint: approximately one major new concept per level; later levels inherit prior literacy.
