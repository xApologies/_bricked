# Flags and Bricking
Flag = local objective/proof artifact; may be plain, geometric, historical, cryptographic or distributed. Flag does not automatically become a persistent Key.

Local/domain brick = player-induced change removes a needed admissible continuation for that domain.
Run brick = required objective becomes unreachable/unrecoverable from current state.

Local exploit success can create global mission failure.
Design discipline: Probe → Map → Understand → Commit.
Bricking should emerge from simulated state, not arbitrary fail triggers.
