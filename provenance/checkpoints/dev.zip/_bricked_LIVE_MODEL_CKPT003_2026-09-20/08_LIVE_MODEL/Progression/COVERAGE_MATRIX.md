# Genesis Literacy Coverage Matrix
Use this instead of a fixed level count.

Maturity: INTRODUCED → PRACTICED → COMBINED → MASTERED.

| System | Intro | Practice | Combined | Mastery |
|---|---|---|---|---|
| Resolution | planned | | | |
| PSSP | planned | | | |
| Corridors | planned | | | |
| Rainbow Road | planned | | | |
| Bandwidth | planned | | | |
| Waves | planned | | | |
| Superposition | planned | | | |
| Coupling/Entanglement | planned | | | |
| Ghosting | planned | | | |
| DECS | planned | | | |
| Persistent Keys | planned | | | |
| Chirality Cycles | planned | | | |
| Provenance | planned | | | |
| Guardian | planned | | | |
| CDN | planned | | | |
| Bricking | planned | | | |
| Exfiltration | planned | | | |

Completion = required systems mastered + final integrated examination with no new fundamental mechanic.
