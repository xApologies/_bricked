# Persistent DECS Key System

Flags are frequent local objectives. Persistent Keys are rare meta-progression objects. Flag != Key.

A Key is a reusable structured information object with state/history. Candidate properties: Chirality, Bandwidth, Resolution behavior, provenance, DECS state/epoch and relationships. Exact schema remains OPEN until a level requires it.

At level n the player may own K={K_A,K_B,K_C,K_D,K_E}. A puzzle exposes target L_n and may require only a subset such as {K_B,K_C,K_E}. Selected Keys can act as anchors/vertices establishing a bounded Resolution field. Their joint evolving state is manipulated until it realizes the target graph/manifold/condition.

Rules:
1. No Key every level.
2. Keys are not colored keycards.
3. Combinations are structural, not arbitrary recipes.
4. Reuse Keys across distant levels.
5. Optional Keys may enable alternate valid solutions.
6. Use does not normally consume a Key.
7. Key state/history may evolve through prior use.
8. Final mastery tests trajectories/relationships, not merely possession.

A small Key set yields many subsets without inventory inflation. The final DECS may be the state trajectory constructed with all accumulated Keys rather than a simultaneous "insert all keys" lock.
