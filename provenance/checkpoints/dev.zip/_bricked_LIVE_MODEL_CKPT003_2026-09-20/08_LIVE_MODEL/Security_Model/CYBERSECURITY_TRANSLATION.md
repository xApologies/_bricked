# Cybersecurity → Genesis Translation

Conventional cybersecurity remains the conceptual backbone.

Examples:
- reconnaissance -> probing / Resolution discovery
- addressing -> projected/local address representation
- routing -> Corridors / Rainbow Roads
- authentication -> identity/history/state validation
- authorization -> admissibility
- trust relationship -> Chirality coupling / dependency
- network segmentation -> bounded domains/interfaces
- cryptographic state -> DECS
- monitoring -> Guardian/CDN observation
- lateral movement -> cross-domain Corridor/Ghosting mechanics
- exfiltration -> Flag/information extraction through an admissible egress
- availability failure -> local/domain brick
- unrecoverable objective -> `_BRICKED`

Rule: each puzzle starts from a legitimate cybersecurity problem, realizes it in the alien architecture, then makes that state visually legible.
