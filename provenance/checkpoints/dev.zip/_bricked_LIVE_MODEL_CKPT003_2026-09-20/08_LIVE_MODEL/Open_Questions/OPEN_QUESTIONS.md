# Open Questions — CKPT002
1. Exact 7D–8D Shell topology/semantics.
2. Individual meanings of 9,10,11.
3. Genesis Horizon cycle mechanism.
4. Horizon ordering vs local Chirality Cycles.
5. Exact Ghosting mathematics.
6. Ghosting vs entanglement/superposition.
7. Historical Ghosting rewrite semantics.
8. White coherence condition.
9. Neon/Möbius underside.
10. Persistent DECS Key schema and first actual Key designs.
11. Rainbow Road bus scheduling/buffering/concurrency.
12. Python binary serialization/wire format.
13. Genesis Language integration.
14. Production platform/render architecture.
15. Final level count (deliberately emergent).
