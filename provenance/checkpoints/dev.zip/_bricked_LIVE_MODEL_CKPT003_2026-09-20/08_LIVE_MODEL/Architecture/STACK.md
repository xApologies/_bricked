# Architecture Stack — Working Canon

Genesis Machine (hackable through 8D)
  ↓
Genesis Horizon (9D–11D container/reference structure)
  ↕
Rainbow Road (candidate native transport/data-bus organization)
  ↕
Python Sandbox (bidirectional transduction VM)
  ↕
Platform Adapter
  ↕
Renderer / GPU / device

## Boundary rule
The simulated Genesis machine may be intentionally compromised by the player. Host authority must not be implied by in-game authority.

## Implementation status
DESIGN ONLY. Genesis Language exists upstream but has not yet been integrated into this checkpoint. No engine implementation is claimed.
