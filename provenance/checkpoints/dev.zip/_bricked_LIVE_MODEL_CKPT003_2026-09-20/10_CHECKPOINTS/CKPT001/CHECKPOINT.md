# CKPT001 — Live Model Bootstrap
Date: 2026-09-20

## Purpose
Convert the conversation's accepted `_bricked` architecture/game-design state into a cumulative live model that can be extended checkpoint by checkpoint.

## Added
- Live-model architecture summary
- Genesis visual contract
- Cybersecurity-to-Genesis translation
- Chirality-cycle/provenance model
- Ghosting working abstraction
- Open-question register
- Source/provenance index
- Cumulative checkpoint policy

## Preserved
- Development Landscape v0.1
- FIRST LIGHT initial level structure/brief
- Existing production pipeline

## Rule for future checkpoints
Every new checkpoint copies the entire previous checkpoint and adds/updates material. No checkpoint is a delta-only package.
