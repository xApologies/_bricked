# _bricked — Development Landscape v0.1

Canonical production pipeline for every `_bricked` level.

A level is COMPLETE only after:
Brief → Cybersecurity Landscape → Puzzle Mathematics → State Machine → Greybox → Vertical Slice → Implementation → Adversarial Test → Performance + Platform → Polish → Gold.

Each gate is iterative. Failure returns the level to the appropriate earlier checkpoint.

Shared architecture belongs in CANON / GAME_SYSTEMS / ENGINE. Levels instantiate those systems; they do not silently redefine them.

FIRST LIGHT is the initial vertical-slice/template level.

Roles:
- Genesis — creative direction, architecture, world rules.
- Astraeus — systems, cybersecurity, puzzle architecture.
- Vera — ledger, provenance, audit, regression, checkpoint control.

Current spine:
Genesis Machine → Genesis Horizon ↔ Rainbow Road ↔ Python Sandbox / transduction VM ↔ platform ↔ renderer/device.


## Live Model / cumulative checkpoint policy

Starting with CKPT001, `_bricked` is maintained as a cumulative live model.
Each checkpoint ZIP is self-contained: copy the previous checkpoint, preserve prior accepted material, update the live model and Vera ledger, and add new design/source artifacts.
The ZIP should grow as the project grows; future checkpoints are not delta-only patches.

## CKPT002
Content-production architecture, first ten post-intro levels, mastery-based game sizing, and persistent DECS Key progression added. See `10_CHECKPOINTS/CKPT002/CHECKPOINT.md`.
