# LEVEL PIPELINE

## CKPT 0 — Brief
Gate: explain the level simply.
Record player fantasy, Flag/objective, lesson, intended vulnerability, intended solution, BRICKED condition, dependencies.

## CKPT 1 — Cybersecurity Landscape
Owner: Astraeus.
Gate: defender and machine are coherent before the exploit.
Record assets, domains, trust boundaries, Guardian, DECS, CDN, Corridors/Portals/Rainbow Roads, attacker start, defender assumptions.

## CKPT 2 — Puzzle Mathematics
Gate: solvable on paper.
Record initial state, Resolution, Bandwidth, Occupancy, Chirality, History, waves, coupling/entanglement, admissible transformations, invariants, Flag condition, failure conditions.

## CKPT 3 — State Machine
Audit: Vera.
Gate: important transitions are enumerable/testable.
Record intended path, alternate paths, victory, soft bricks, hard bricks, reachability invariants.

## CKPT 4 — Greybox
Gate: fun and understandable with placeholder geometry. Test discovery, signaling, interaction, accidental solutions, reversibility and bricking.

## CKPT 5 — Vertical Slice
Gate: representative final visual/audio language communicates the same machine state as the greybox.
Rule: beauty carries information.

## CKPT 6 — Implementation
Gate: one authoritative implementation.
Genesis owns game behavior; Horizon boundary; Rainbow Road transport; Python sandbox/transduction; platform native integration; renderer realization.

## CKPT 7 — Adversarial Test
Gate: deliberate break attempts recorded and addressed.
Test strange ordering, duplicate/invalid Flags, Bandwidth saturation, interrupted Corridors, Guardian edge cases, save/load transitions, corruption/recovery, shortcuts, brick correctness.

## CKPT 8 — Performance + Platform
Gate: target budgets met. Profile frame pacing, memory, thermals/battery, latency, serialization/transport, sandbox overhead, save/load and device variation.

## CKPT 9 — Polish
Gate: no new core mechanics. Tune feedback, haptics, audio, accessibility, color differentiation, reduced effects, irreversible-action signaling, environment and secrets.

## CKPT 10 — Gold
Owner: Vera.
Gate: frozen reproducible package with version, dependencies, assets, tests, known issues and provenance.

COMPLETE exists only after CKPT 10 passes.
