# Source / Provenance Index

This checkpoint is a project-state package, not a replacement for the full source corpus.

Source families currently informing the live model include:
- Genesis Chirality Fabric R62 corpus (A–U / assembly / handoff)
- Genesis Field
- Rainbow Road
- DECS / Chirality Defense Network proposals
- Genesis Mainframe / computer architecture packages
- BRANE 1.0 blueprint and later implementation reference
- Trinity 3.0
- MK Ultra / Tome material
- Chirality propagation package
- Phase State Shadow Projection package
- Resolution Operator and related candidate packages

The full source archives remain external to this compact live-model checkpoint unless explicitly vendored into a later checkpoint.
